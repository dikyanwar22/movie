<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\M_home;

class Home extends Controller {

  public function index() {
    $model = new M_home();
    $data['title'] = 'The Movie Database';
    $data['film'] = $model->db_films();
    return view('welcome',$data);
  }

  public function detail($id_film) {
    $model = new M_home();
    $data['title'] = 'The Movie Database';
    $data['v'] = $model->db_detailfilm($id_film);
    return view('detail',$data);
  }

}

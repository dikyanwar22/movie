<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class M_home extends Model {
    use HasFactory;

    public function db_films() {
      $db = DB::table('films')
      ->orderBy('id_film','desc');
      return $db;
    }

    public function db_detailfilm($id_film) {
      $db = DB::table('films')
      ->where('films.id_film',$id_film);
      return $db->first();
    }

}
